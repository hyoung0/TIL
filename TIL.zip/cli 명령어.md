# CLI
 : 명령 기반의 인터페이스  

## 기초 파일시스템 명령어
- ls : 목록(list)
- mkdir : 디렉토리 생성(make directory)
- cd : 디렉토리 이동(change directory)
- . : 현재 디렉토리
- .. : 상위 디렉토리
- touch 파일명 : 새로운 파일을 생성
- rm 파일명 : 파일 삭제(remove)
- rm -r b 폴더명: 폴더 삭제하기
 (폴더는 안에 있는 파일을 다 지워야 되므로 바로 지우기 힘드므로)

